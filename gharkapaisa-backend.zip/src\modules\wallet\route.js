const express = require('express');
const router = express.Router();
const walletCtrl = require('./controller.js');
const { authenticate, syncUser, authorize, requireApprovedPartner, requireApprovedPartnerOrAdmin, selfOrAdmin } = require('../../middleware/authentication/auth.middleware.js');
const { withdrawalRules, validate } = require('../../middleware/validation/validation.middleware.js');
const { withdrawalOtpLimiter, validateBankDetails, validateWithdrawalAmount } = require('./middleware.js');

router.use(authenticate, syncUser);

// Bank Details: All (Sub-routes declared first to eliminate path conflicts)
router.get('/bank-details/all', requireApprovedPartnerOrAdmin, walletCtrl.getAllBankDetails);
router.get('/bank-details/history', requireApprovedPartnerOrAdmin, walletCtrl.getBankEditHistory);
router.post('/bank-details/secondary', requireApprovedPartner, validateBankDetails, walletCtrl.addSecondaryBankDetail);
router.post('/bank-details/primary', requireApprovedPartner, walletCtrl.setPrimaryBank);
router.post('/bank-details/verify/penny-drop', requireApprovedPartner, walletCtrl.verifyBankPennyDrop);
router.post('/bank-details/verify/upi', requireApprovedPartner, walletCtrl.verifyBankUPI);
router.get('/bank-details', requireApprovedPartnerOrAdmin, walletCtrl.getBankDetails);
router.post('/bank-details', requireApprovedPartnerOrAdmin, validateBankDetails, walletCtrl.saveBankDetails);
router.put('/bank-details', requireApprovedPartnerOrAdmin, validateBankDetails, walletCtrl.saveBankDetails);

// Withdrawals Routing (Admin & Polymorphic Partner Handlers)
router.get('/admin/overview', authorize('ADMIN', 'SUPER_ADMIN'), walletCtrl.getWalletOverview);
router.get('/admin/partners-overview', authorize('ADMIN', 'SUPER_ADMIN'), walletCtrl.getPartnersOverview);
router.get('/admin/razorpay/balance', authorize('ADMIN', 'SUPER_ADMIN'), walletCtrl.getRazorpayAccountSummary);

// Razorpay Add Funds Requests (Super Admin)
router.post('/admin/fund-requests', authorize('SUPER_ADMIN', 'ADMIN'), walletCtrl.createAddFundsRequest);
router.get('/admin/fund-requests', authorize('SUPER_ADMIN', 'ADMIN'), walletCtrl.getAddFundsRequests);
router.patch('/admin/fund-requests/:id/submit', authorize('SUPER_ADMIN', 'ADMIN'), walletCtrl.submitAddFundsUTR);
router.patch('/admin/fund-requests/:id/reconcile', authorize('SUPER_ADMIN', 'ADMIN'), walletCtrl.reconcileAddFundsRequest);

router.post('/admin/adjust', authorize('ADMIN', 'SUPER_ADMIN'), walletCtrl.adminAdjustWalletController);
router.get('/admin/withdrawals', requireApprovedPartnerOrAdmin, walletCtrl.listWithdrawals);
router.post('/admin/withdrawals/:id/approve', authorize('ADMIN', 'SUPER_ADMIN'), walletCtrl.approveWithdrawalController);
router.post('/admin/withdrawals/:id/reject', authorize('ADMIN', 'SUPER_ADMIN'), walletCtrl.rejectWithdrawalController);
router.post('/admin/withdrawals/:id/process', authorize('ADMIN', 'SUPER_ADMIN'), walletCtrl.processWithdrawalRequest);
router.get('/my-withdrawals', requireApprovedPartner, walletCtrl.listPartnerWithdrawals);
router.get('/withdrawals', requireApprovedPartnerOrAdmin, walletCtrl.listWithdrawals);
router.patch('/withdrawals/:id/process', authorize('ADMIN', 'SUPER_ADMIN'), walletCtrl.processWithdrawalRequest);
router.get('/admin/commissions/pending', authorize('ADMIN', 'SUPER_ADMIN'), walletCtrl.getPendingCommissions);
router.get('/admin/team-commissions', authorize('ADMIN', 'SUPER_ADMIN'), walletCtrl.getTeamCommissionsBreakdown);
router.post('/admin/commissions/:transactionId/release', authorize('ADMIN', 'SUPER_ADMIN'), walletCtrl.releaseCommission);
router.post('/admin/commissions/:transactionId/reject', authorize('ADMIN', 'SUPER_ADMIN'), walletCtrl.rejectCommission);
router.post('/admin/wallet/release/:transactionId', authorize('ADMIN', 'SUPER_ADMIN'), walletCtrl.releaseCommission);
router.post('/admin/wallet/reject/:transactionId', authorize('ADMIN', 'SUPER_ADMIN'), walletCtrl.rejectCommission);
router.post('/withdrawals/:id/cancel', requireApprovedPartner, walletCtrl.cancelWithdrawal);
router.post('/withdrawals/:id/retry', requireApprovedPartner, walletCtrl.retryWithdrawal);
router.get('/withdrawals/:id', requireApprovedPartnerOrAdmin, walletCtrl.getWithdrawalDetail);

// Partner self-endpoints (no ID needed in URL)
router.get('/', requireApprovedPartnerOrAdmin, walletCtrl.getWallet);
router.get('/dashboard', requireApprovedPartnerOrAdmin, walletCtrl.getWalletDashboard);
router.get('/balance', requireApprovedPartnerOrAdmin, walletCtrl.getWallet);
router.get('/ledger', requireApprovedPartnerOrAdmin, walletCtrl.getWalletLedger);
router.get('/transactions', requireApprovedPartnerOrAdmin, walletCtrl.getTransactions);
router.get('/commission-summary', requireApprovedPartnerOrAdmin, walletCtrl.getCommissionSummary);
router.get('/analytics', requireApprovedPartnerOrAdmin, walletCtrl.getWalletAnalyticsController);
router.get('/reconciliation', requireApprovedPartnerOrAdmin, walletCtrl.getWalletReconciliationController);
router.get('/statement', requireApprovedPartnerOrAdmin, walletCtrl.getWalletStatementController);

// Statement Export
router.get('/statement/pdf', requireApprovedPartnerOrAdmin, walletCtrl.exportStatementPDF);
router.get('/statement/excel', requireApprovedPartnerOrAdmin, walletCtrl.exportStatementExcel);

// OTP & Withdrawals (Partner)
router.post('/withdraw/otp/send', withdrawalOtpLimiter, requireApprovedPartnerOrAdmin, walletCtrl.sendWithdrawalOTP);
router.post('/withdraw/otp/verify', requireApprovedPartnerOrAdmin, walletCtrl.verifyWithdrawalOTP);
router.post('/withdraw', requireApprovedPartnerOrAdmin, validateWithdrawalAmount, withdrawalRules, validate, walletCtrl.requestWithdrawal);

// Parameterized Partner ID Routes (placed at the end to prevent route conflicts)
router.get('/:PartnerId', selfOrAdmin('PartnerId'), requireApprovedPartnerOrAdmin, walletCtrl.getWallet);
router.get('/:PartnerId/transactions', selfOrAdmin('PartnerId'), requireApprovedPartnerOrAdmin, walletCtrl.getTransactions);
router.get('/:PartnerId/case-summary', selfOrAdmin('PartnerId'), requireApprovedPartnerOrAdmin, walletCtrl.getCaseSummary);
router.post('/:PartnerId/withdraw', selfOrAdmin('PartnerId'), requireApprovedPartnerOrAdmin, withdrawalRules, validate, walletCtrl.requestWithdrawal);

module.exports = router;
