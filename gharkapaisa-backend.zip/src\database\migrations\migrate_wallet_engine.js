const { query, pool } = require('../../config/database');
const logger = require('../../config/logger');

const runWalletEngineMigrations = async () => {
  logger.info('Starting Wallet Engine Database Migrations...');

  try {
    // 1. Transaction Type Enum
    await query(`
      DO $$
      BEGIN
        IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'ledger_transaction_type') THEN
          CREATE TYPE ledger_transaction_type AS ENUM (
            'PERSONAL_COMMISSION', 
            'TEAM_COMMISSION', 
            'REFERRAL_BONUS', 
            'CAMPAIGN_BONUS', 
            'SETTLEMENT', 
            'WITHDRAWAL', 
            'ADJUSTMENT', 
            'REVERSAL', 
            'REFUND',
            'TDS_DEDUCTION',
            'COMMISSION_RELEASE',
            'OVERRIDE_COMMISSION'
          );
        END IF;
      END $$;
    `);

    // 1b. Enforce Non-Negative Balance Constraints on partner_wallets
    await query(`
      DO $$
      BEGIN
        IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'chk_available_balance_non_negative') THEN
          ALTER TABLE partner_wallets ADD CONSTRAINT chk_available_balance_non_negative CHECK (available_balance >= 0);
        END IF;
        IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'chk_hold_balance_non_negative') THEN
          ALTER TABLE partner_wallets ADD CONSTRAINT chk_hold_balance_non_negative CHECK (hold_balance >= 0);
        END IF;
      END $$;
    `);

    // 2. Wallet Ledger Table
    await query(`
      CREATE TABLE IF NOT EXISTS wallet_ledger (
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        wallet_id UUID NOT NULL REFERENCES partner_wallets(id),
        partner_id UUID NOT NULL REFERENCES partner_profiles(id),
        application_id UUID REFERENCES applications(id),
        transaction_type ledger_transaction_type NOT NULL,
        credit DECIMAL(15,2) DEFAULT 0,
        debit DECIMAL(15,2) DEFAULT 0,
        balance_after_transaction DECIMAL(15,2) DEFAULT 0,
        description VARCHAR(500),
        reference_number VARCHAR(100),
        status VARCHAR(50) DEFAULT 'completed',
        created_by UUID REFERENCES users(id),
        created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);

    await query(`
      CREATE UNIQUE INDEX IF NOT EXISTS idx_wallet_ledger_unique_commission 
      ON wallet_ledger(application_id, transaction_type, partner_id) 
      WHERE application_id IS NOT NULL;
    `);

    // 3. Commission Rules Table
    await query(`
      CREATE TABLE IF NOT EXISTS commission_rules (
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        product_id UUID REFERENCES products(id),
        partner_percentage DECIMAL(5,2) DEFAULT 90.00,
        parent_percentage DECIMAL(5,2) DEFAULT 10.00,
        campaign_bonus DECIMAL(15,2) DEFAULT 0.00,
        effective_from TIMESTAMPTZ DEFAULT NOW(),
        effective_to TIMESTAMPTZ,
        status VARCHAR(50) DEFAULT 'active',
        created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);

    // 4. Wallet Withdrawals Table
    await query(`
      CREATE TABLE IF NOT EXISTS wallet_withdrawals (
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        partner_id UUID REFERENCES partner_profiles(id),
        amount DECIMAL(15,2) NOT NULL,
        bank_account VARCHAR(100),
        ifsc VARCHAR(20),
        status VARCHAR(50) DEFAULT 'pending',
        requested_at TIMESTAMPTZ DEFAULT NOW(),
        approved_at TIMESTAMPTZ,
        approved_by UUID REFERENCES users(id),
        transaction_reference VARCHAR(100)
      );

      ALTER TABLE wallet_withdrawals ADD COLUMN IF NOT EXISTS wallet_id UUID REFERENCES partner_wallets(id);
      ALTER TABLE wallet_withdrawals ADD COLUMN IF NOT EXISTS currency VARCHAR(10) DEFAULT 'INR';
      ALTER TABLE wallet_withdrawals ADD COLUMN IF NOT EXISTS tds_rate NUMERIC(5,2) DEFAULT 2.00;
      ALTER TABLE wallet_withdrawals ADD COLUMN IF NOT EXISTS tds_amount NUMERIC(15,2) DEFAULT 0.00;
      ALTER TABLE wallet_withdrawals ADD COLUMN IF NOT EXISTS net_amount NUMERIC(15,2);
      ALTER TABLE wallet_withdrawals ADD COLUMN IF NOT EXISTS bank_name VARCHAR(255);
      ALTER TABLE wallet_withdrawals ADD COLUMN IF NOT EXISTS account_number VARCHAR(100);
      ALTER TABLE wallet_withdrawals ADD COLUMN IF NOT EXISTS ifsc_code VARCHAR(50);
      ALTER TABLE wallet_withdrawals ADD COLUMN IF NOT EXISTS bank_account_id UUID;
      ALTER TABLE wallet_withdrawals ADD COLUMN IF NOT EXISTS idempotency_key VARCHAR(255);
      ALTER TABLE wallet_withdrawals ADD COLUMN IF NOT EXISTS razorpay_contact_id VARCHAR(100);
      ALTER TABLE wallet_withdrawals ADD COLUMN IF NOT EXISTS razorpay_fund_account_id VARCHAR(100);
      ALTER TABLE wallet_withdrawals ADD COLUMN IF NOT EXISTS razorpay_payout_id VARCHAR(100);
      ALTER TABLE wallet_withdrawals ADD COLUMN IF NOT EXISTS utr VARCHAR(100);
      ALTER TABLE wallet_withdrawals ADD COLUMN IF NOT EXISTS bank_reference VARCHAR(100);
      ALTER TABLE wallet_withdrawals ADD COLUMN IF NOT EXISTS failure_reason TEXT;
      ALTER TABLE wallet_withdrawals ADD COLUMN IF NOT EXISTS rejection_reason TEXT;
      ALTER TABLE wallet_withdrawals ADD COLUMN IF NOT EXISTS remarks TEXT;
      ALTER TABLE wallet_withdrawals ADD COLUMN IF NOT EXISTS admin_note TEXT;
      ALTER TABLE wallet_withdrawals ADD COLUMN IF NOT EXISTS processed_at TIMESTAMPTZ;
      ALTER TABLE wallet_withdrawals ADD COLUMN IF NOT EXISTS processed_by UUID REFERENCES users(id);
      ALTER TABLE wallet_withdrawals ADD COLUMN IF NOT EXISTS transferred_at TIMESTAMPTZ;
      ALTER TABLE wallet_withdrawals ADD COLUMN IF NOT EXISTS transferred_by UUID REFERENCES users(id);
      ALTER TABLE wallet_withdrawals ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW();

      -- Align partner_bank_details columns
      ALTER TABLE partner_bank_details ADD COLUMN IF NOT EXISTS razorpay_contact_id VARCHAR(100);
      ALTER TABLE partner_bank_details ADD COLUMN IF NOT EXISTS razorpay_fund_account_id VARCHAR(100);
      ALTER TABLE partner_bank_details ADD COLUMN IF NOT EXISTS is_primary BOOLEAN DEFAULT TRUE;
      ALTER TABLE partner_bank_details ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT TRUE;
    `);

    // 5. Wallet Withdrawal Events Table (Audit Trail)
    await query(`
      CREATE TABLE IF NOT EXISTS wallet_withdrawal_events (
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        withdrawal_id UUID NOT NULL REFERENCES wallet_withdrawals(id) ON DELETE CASCADE,
        status VARCHAR(50) NOT NULL,
        remarks TEXT,
        changed_by UUID REFERENCES users(id),
        created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);

    // 6. Fund Requests Table
    await query(`
      CREATE TABLE IF NOT EXISTS fund_requests (
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        partner_id UUID REFERENCES partner_profiles(id) ON DELETE CASCADE,
        amount DECIMAL(15,2) NOT NULL,
        payment_method VARCHAR(50) DEFAULT 'bank_transfer',
        status VARCHAR(50) DEFAULT 'pending',
        reference_number VARCHAR(100),
        purpose TEXT,
        created_at TIMESTAMPTZ DEFAULT NOW(),
        updated_at TIMESTAMPTZ DEFAULT NOW(),
        processed_by UUID REFERENCES users(id) ON DELETE SET NULL,
        processed_at TIMESTAMPTZ,
        remarks TEXT
      )
    `);

    logger.info('Wallet Engine database migrations completed successfully.');
  } catch (err) {
    logger.error('Error during wallet engine migrations:', err);
    process.exit(1);
  }
};

if (require.main === module) {
  require('dotenv').config();
  runWalletEngineMigrations().then(() => pool.end());
}

module.exports = runWalletEngineMigrations;
