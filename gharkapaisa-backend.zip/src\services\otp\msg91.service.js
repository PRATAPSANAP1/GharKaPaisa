const axios = require('axios');

const VERIFY_ACCESS_TOKEN_URL = 'https://control.msg91.com/api/v5/widget/verifyAccessToken';

const getAuthKey = () => {
  const authKey = process.env.MSG91_AUTH_KEY;
  if (!authKey) {
    throw new Error('MSG91_AUTH_KEY is not configured');
  }
  return authKey;
};

const normalizeIndianMobile = (value) => {
  const digits = String(value || '').replace(/\D/g, '');
  if (/^[6-9]\d{9}$/.test(digits)) return digits;
  if (/^91[6-9]\d{9}$/.test(digits)) return digits.slice(2);
  return null;
};

const findVerifiedIdentifier = (payload) => {
  const candidates = [
    payload?.identifier,
    payload?.mobile,
    payload?.phone,
    payload?.data?.identifier,
    payload?.data?.mobile,
    payload?.data?.phone,
  ];
  return candidates.find(Boolean) || null;
};

const verifyAccessToken = async ({ accessToken, expectedMobile }) => {
  if (!accessToken || typeof accessToken !== "string") {
    throw new Error("MSG91 access token is required");
  }

  try {
    const response = await axios.post(
      VERIFY_ACCESS_TOKEN_URL,
      {
        authkey: getAuthKey(),
        "access-token": accessToken,
      },
      {
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        timeout: 10000,
      }
    );

    const payload = response.data || {};

    const verificationSucceeded =
      payload.success === true ||
      payload.type === "success" ||
      payload.status === "success" ||
      payload.status === true;

    if (!verificationSucceeded) {
      throw new Error(
        payload.message || payload.error || "MSG91 verification failed"
      );
    }

    if (expectedMobile) {
      const requestedMobile = normalizeIndianMobile(expectedMobile);
      const verifiedIdentifier = findVerifiedIdentifier(payload);
      const verifiedMobile = verifiedIdentifier ? normalizeIndianMobile(verifiedIdentifier) : requestedMobile;
      if (!verifiedMobile) {
        throw new Error("MSG91 verification failed to provide a valid mobile number");
      }
      if (requestedMobile && verifiedMobile && requestedMobile !== verifiedMobile) {
        throw new Error("Verified mobile mismatch. Requested number does not match OTP recipient.");
      }
    }
    return payload;

  } catch (err) {

    throw err;
  }
};

const sendSmsOtp = async (mobile, otp) => {
  const authKey = process.env.MSG91_AUTH_KEY || process.env.MSG91_AUTHKEY;
  const templateId = process.env.MSG91_OTP_TEMPLATE_ID;

  const normalized = normalizeIndianMobile(mobile);
  if (!normalized) {
    throw new Error("Invalid Indian mobile number");
  }

  if (authKey && templateId) {
    const url = `https://control.msg91.com/api/v5/otp?template_id=${templateId}&mobile=91${normalized}&authkey=${authKey}&otp=${otp}`;

    try {
      const response = await axios.post(
        url,
        {},
        {
          headers: {
            Accept: "application/json"
          },
          timeout: 10000
        }
      );

      return response.data;
    } catch (err) {
      // Intentionally omit URL/credentials from log
    }
  }

  // Fallback to standard SMS API via sendSms
  try {
    const { sendSms } = require('../sms/sms.service');
    const body = `Your GharKaPaisa verification OTP is ${otp}. Valid for 10 minutes. Do not share.`;
    return await sendSms(mobile, body);
  } catch (fallbackErr) {
    console.log("MSG91 fallback SMS failed:", fallbackErr.message);
    throw fallbackErr;
  }
};

module.exports = {
  normalizeIndianMobile,
  verifyAccessToken,
  sendSmsOtp,
};
